package panel;
import java.awt.Font;
import java.awt.Frame;
import java.awt.List;
import java.util.Hashtable;

import javax.swing.JFrame;

import ij.IJ;
import ij.ImageJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.WindowManager;
import ij.gui.Roi;
import ij.plugin.filter.PlugInFilter;
import ij.plugin.frame.RoiManager;
import ij.process.ImageProcessor;
import ij.process.ShortProcessor;

public class Ins_Test_ProcessFrame implements PlugInFilter {
	ImagePlus imp;

	public int setup(String arg, ImagePlus imp) {
		this.imp = imp;
		return DOES_ALL;
	}

	public void run(ImageProcessor ip) {
		Frame frame = WindowManager.getFrame("ROI Manager");					
		if (frame==null || !(frame instanceof RoiManager))
			{return;}
		RoiManager roiManager = (RoiManager)frame;			
		List list = roiManager.getList();
		Hashtable<String, Roi> rois = roiManager.getROIs();			
		if(list.getItemCount() != 2)
		{
			IJ.showMessage("Need 2 ROI in the manager");
			return;
		}
		Ins_processFrame processFrame = new Ins_processFrame();
		processFrame.setOpaque(true);	
		JFrame frame2 = new JFrame("Bacterial analyzer");
		frame2.setContentPane(processFrame);
		frame2.pack();
		frame2.setResizable(false);
		frame2.setVisible(true);
	}
	
	public void makeMovie()
	{
		ImagePlus imp1 = IJ.openImage();
		ImagePlus imp2 = IJ.openImage();
		ImagePlus imp3 = IJ.openImage();
		
		
		
		
		int ns = Math.max(imp1.getImageStackSize(), imp2.getImageStackSize());
		ns = Math.max(ns, imp3.getImageStackSize());
		
		int width = imp1.getWidth();
		int height = imp1.getHeight();
		ImagePlus imp =IJ.createImage("movie ls", imp1.getWidth()*3+30, imp1.getHeight()+30, ns, imp1.getBitDepth());
		for(int s=1;s<=ns;s++)
		{
			ImageProcessor ip1=null;
			ImageProcessor ip2=null;
			ImageProcessor ip3=null;
			int xloc = 0;
			int yloc = 0;
			ImageProcessor ip = imp.getImageStack().getProcessor(s);
			ip.setValue(65535);;
			ip.setFont(new Font("TimesRoman", Font.PLAIN, 20));

			if(s<=imp1.getImageStackSize())
			{
				ip1 = imp1.getImageStack().getProcessor(s);
				ip.insert(ip1, xloc, yloc);
				ip.drawString("Lifespan 10-40h", (int)(width*0.5)-55, (int)height+25);

			}

			if(s<=imp2.getImageStackSize())
			{
				ip2 = imp2.getImageStack().getProcessor(s);
				ip.insert(ip2, xloc+width+10, yloc);
				ip.drawString("Lifespan 40-70h", (int)(width+width*0.5-45), (int)height+25);
			}
				
			if(s<=imp3.getImageStackSize())
			{
				ip3 = imp3.getImageStack().getProcessor(s);
				ip.insert(ip3, xloc+width+10+width+10, yloc);
				ip.drawString("Lifespan 70-90h", (int)(width+10+width+width*0.5-50), (int)height+25);
			}
						

			
			
		}
		imp.show();
	}
	
	public static void main(String[] args)
	{
		ImageJ ij = new ImageJ();
		Ins_Test_ProcessFrame ins_Test_ProcessFrame = new Ins_Test_ProcessFrame();
		ins_Test_ProcessFrame.makeMovie();
	}
}

