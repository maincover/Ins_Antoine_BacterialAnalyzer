package psf;

public class Pstruct {

}
